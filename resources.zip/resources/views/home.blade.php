@extends('layout.master')
@push('plugin-styles')
<link href="{{ asset('/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css') }}" rel="stylesheet" />
@endpush
@section('content')
<div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
   <div>
      <h4 class="mb-3 mb-md-0">Welcome! Dashboard</h4>
   </div>
   <div class="d-flex align-items-center flex-wrap text-nowrap">
      <div class="input-group date datepicker dashboard-date mr-2 mb-2 mb-md-0 d-md-none d-xl-flex" id="dashboardDate">
         <span class="input-group-addon bg-transparent"><i data-feather="calendar" class=" text-primary"></i></span>
         <input type="text" class="form-control">
      </div>
      {{-- <button type="button" class="btn btn-outline-info btn-icon-text mr-2 d-none d-md-block">
      <i class="btn-icon-prepend" data-feather="download"></i>
      Import
      </button> --}}
      <button type="button" class="btn btn-outline-primary btn-icon-text mr-2 mb-2 mb-md-0">
      <i class="btn-icon-prepend" data-feather="printer"></i>
      Print
      </button>
      {{-- <button type="button" class="btn btn-primary btn-icon-text mb-2 mb-md-0">
      <i class="btn-icon-prepend" data-feather="download-cloud"></i>
      Download Report
      </button> --}}
   </div>
</div>
<div class="row">
   <div class="col-12 col-xl-12 stretch-card">
      <div class="row flex-grow">
         <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <div class="d-flex justify-content-between align-items-baseline">
                     <h6 class="card-title mb-0">Total Customers</h6>
                     <div class="dropdown mb-2">
                        <button class="btn p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </button>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-6 col-md-12 col-xl-5">
                        <h3 class="mb-2">{{$customer_total}}</h3>
                     </div>
                     <div class="col-6 col-md-12 col-xl-7">
                        <div id="sparklineArea"></div>
                     </div>
                     {{--  
                     <div class="col-6 col-md-12 col-xl-5">
                        <i class="fa fa-user-o" aria-hidden="true"></i></h3>
                     </div>
                     --}}
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <div class="d-flex justify-content-between align-items-baseline">
                     <h6 class="card-title mb-0">Total Suppliers</h6>
                     <div class="dropdown mb-2">
                        <button class="btn p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </button>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-6 col-md-12 col-xl-5">
                        <h3 class="mb-2">{{$supplier_total}}</h3>
                     </div>
                     <div class="col-6 col-md-12 col-xl-7">
                        <div id="sparklineLine"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <div class="d-flex justify-content-between align-items-baseline">
                     <h6 class="card-title mb-0">Total Products</h6>
                     <div class="dropdown mb-2">
                        <button class="btn p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </button>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-6 col-md-12 col-xl-5">
                        <h3 class="mb-2">{{$product_total}}</h3>
                     </div>
                     <div class="col-6 col-md-12 col-xl-7">
                        <div id="sparklineBar"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <div class="d-flex justify-content-between align-items-baseline">
                     <h6 class="card-title mb-0">Today Total Invoice</h6>
                     <div class="dropdown mb-2">
                        <button class="btn p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </button>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-6 col-md-12 col-xl-5">
                        <h3 class="mb-2">{{$today_total_sale}}</h3>
                     </div>
                     <div class="col-6 col-md-12 col-xl-7">
                        <div id="apexChart1" class="mt-md-3 mt-xl-0"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <div class="d-flex justify-content-between align-items-baseline">
                     <h6 class="card-title mb-0">Today Total Purchase</h6>
                     <div class="dropdown mb-2">
                        <button class="btn p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </button>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-6 col-md-12 col-xl-5">
                        <h3 class="mb-2">{{$today_total_purchase}}</h3>
                     </div>
                     <div class="col-6 col-md-12 col-xl-7">
                        <div id="apexChart2" class="mt-md-3 mt-xl-0"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
               <div class="card-body">
                  <div class="d-flex justify-content-between align-items-baseline">
                     <h6 class="card-title mb-0">Today Total Cash Bill</h6>
                     <div class="dropdown mb-2">
                        <button class="btn p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </button>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-6 col-md-12 col-xl-5">
                        <h3 class="mb-2">{{$today_total_cash}}</h3>
                     </div>
                     <div class="col-6 col-md-12 col-xl-7">
                        <div id="apexChart3" class="mt-md-3 mt-xl-0"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- row -->
<div class="row">
   <div class="col-md-12 grid-margin stretch-card">
      <h4 class="card-title">Quick Access</h4>
   </div>
</div>
<div class="row">
   <div class="col-md-4 grid-margin stretch-card">
      <div class="card">
         <div class="card-body d-flex flex-column align-items-center">
            <p class="card-description">Create GST Invoice</p>
            <a href="/sales-invoices/create" class="btn btn-primary">Click here!</a>
         </div>
      </div>
   </div>
   <div class="col-md-4 grid-margin stretch-card">
      <div class="card">
         <div class="card-body d-flex flex-column align-items-center">
            <p class="card-description">Create Cash Bill</p>
            <a href="/cash-bills/create" class="btn btn-primary">Click here!</a>
         </div>
      </div>
   </div>
   <div class="col-md-4 grid-margin stretch-card">
      <div class="card">
         <div class="card-body d-flex flex-column align-items-center">
            <p class="card-description">Create Purchase Invoice</p>
            <a href="/purchase-invoices/create" class="btn btn-primary">Click here!</a>
         </div>
      </div>
   </div>
   <div class="col-md-4 grid-margin stretch-card">
      <div class="card">
         <div class="card-body d-flex flex-column align-items-center">
            <p class="card-description">Create Product</p>
            <a href="/products/create" class="btn btn-primary">Click here!</a>
         </div>
      </div>
   </div>
   <div class="col-md-4 grid-margin stretch-card">
      <div class="card">
         <div class="card-body d-flex flex-column align-items-center">
            <p class="card-description">Create Customer</p>
            <a href="/customers/create" class="btn btn-primary">Click here!</a>
         </div>
      </div>
   </div>
   <div class="col-md-4 grid-margin stretch-card">
      <div class="card">
         <div class="card-body d-flex flex-column align-items-center">
            <p class="card-description">Create Supplier</p>
            <a href="/vendors/create" class="btn btn-primary">Click here!</a>
         </div>
      </div>
   </div>
</div>
<div class="row">
   <div class="col-xl-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <h6 class="card-title"></h6>
            <canvas id="chartjsLine"></canvas>
         </div>
      </div>
   </div>
</div>
{{-- 
<div class="row">
   <div class="col-lg-7 col-xl-8 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <div class="d-flex justify-content-between align-items-baseline mb-2">
               <h6 class="card-title mb-0">Monthly sales</h6>
               <div class="dropdown mb-2">
                  <button class="btn p-0" type="button" id="dropdownMenuButton4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton4">
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                  </div>
               </div>
            </div>
            <p class="text-muted mb-4">Sales are activities related to selling or the number of goods or services sold in a given time period.</p>
            <div class="monthly-sales-chart-wrapper">
               <canvas id="pieChart"></canvas>
            </div>
         </div>
      </div>
   </div>
</div>
--}}
{{-- 
<div class="row">
   <div class="col-12 col-xl-12 grid-margin stretch-card">
      <div class="card overflow-hidden">
         <div class="card-body">
            <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3">
               <h6 class="card-title mb-0">Revenue</h6>
               <div class="dropdown">
                  <button class="btn p-0" type="button" id="dropdownMenuButton3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton3">
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                  </div>
               </div>
            </div>
            <div class="row align-items-start mb-2">
               <div class="col-md-7">
                  <p class="text-muted tx-13 mb-3 mb-md-0">Revenue is the income that a business has from its normal business activities, usually from the sale of goods and services to customers.</p>
               </div>
               <div class="col-md-5 d-flex justify-content-md-end">
                  <div class="btn-group mb-3 mb-md-0" role="group" aria-label="Basic example">
                     <button type="button" class="btn btn-outline-primary">Today</button>
                     <button type="button" class="btn btn-outline-primary d-none d-md-block">Week</button>
                     <button type="button" class="btn btn-primary">Month</button>
                     <button type="button" class="btn btn-outline-primary">Year</button>
                  </div>
               </div>
            </div>
            <div class="flot-wrapper">
               <div id="flotChart1" class="flot-chart"></div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- row -->
<div class="row">
   <div class="col-lg-7 col-xl-8 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <div class="d-flex justify-content-between align-items-baseline mb-2">
               <h6 class="card-title mb-0">Monthly sales</h6>
               <div class="dropdown mb-2">
                  <button class="btn p-0" type="button" id="dropdownMenuButton4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton4">
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                  </div>
               </div>
            </div>
            <p class="text-muted mb-4">Sales are activities related to selling or the number of goods or services sold in a given time period.</p>
            <div class="monthly-sales-chart-wrapper">
               <canvas id="monthly-sales-chart"></canvas>
            </div>
         </div>
      </div>
   </div>
   <div class="col-lg-5 col-xl-4 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <div class="d-flex justify-content-between align-items-baseline mb-2">
               <h6 class="card-title mb-0">Cloud storage</h6>
               <div class="dropdown mb-2">
                  <button class="btn p-0" type="button" id="dropdownMenuButton5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton5">
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                  </div>
               </div>
            </div>
            <div id="progressbar1" class="mx-auto"></div>
            <div class="row mt-4 mb-3">
               <div class="col-6 d-flex justify-content-end">
                  <div>
                     <label class="d-flex align-items-center justify-content-end tx-10 text-uppercase font-weight-medium">Total storage <span class="p-1 ml-1 rounded-circle bg-primary-muted"></span></label>
                     <h5 class="font-weight-bold mb-0 text-right">8TB</h5>
                  </div>
               </div>
               <div class="col-6">
                  <div>
                     <label class="d-flex align-items-center tx-10 text-uppercase font-weight-medium"><span class="p-1 mr-1 rounded-circle bg-primary"></span> Used storage</label>
                     <h5 class="font-weight-bold mb-0">6TB</h5>
                  </div>
               </div>
            </div>
            <button class="btn btn-primary btn-block">Upgrade storage</button>
         </div>
      </div>
   </div>
</div>
<!-- row -->
<div class="row">
   <div class="col-lg-5 col-xl-4 grid-margin grid-margin-xl-0 stretch-card">
      <div class="card">
         <div class="card-body">
            <div class="d-flex justify-content-between align-items-baseline mb-2">
               <h6 class="card-title mb-0">Inbox</h6>
               <div class="dropdown mb-2">
                  <button class="btn p-0" type="button" id="dropdownMenuButton6" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton6">
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                  </div>
               </div>
            </div>
            <div class="d-flex flex-column">
               <a href="#" class="d-flex align-items-center border-bottom pb-3">
                  <div class="mr-3">
                     <img src="{{ url('https://via.placeholder.com/35x35') }}" class="rounded-circle wd-35" alt="user">
                  </div>
                  <div class="w-100">
                     <div class="d-flex justify-content-between">
                        <h6 class="text-body mb-2">Leonardo Payne</h6>
                        <p class="text-muted tx-12">12.30 PM</p>
                     </div>
                     <p class="text-muted tx-13">Hey! there I'm available...</p>
                  </div>
               </a>
               <a href="#" class="d-flex align-items-center border-bottom py-3">
                  <div class="mr-3">
                     <img src="{{ url('https://via.placeholder.com/35x35') }}" class="rounded-circle wd-35" alt="user">
                  </div>
                  <div class="w-100">
                     <div class="d-flex justify-content-between">
                        <h6 class="text-body mb-2">Carl Henson</h6>
                        <p class="text-muted tx-12">02.14 AM</p>
                     </div>
                     <p class="text-muted tx-13">I've finished it! See you so..</p>
                  </div>
               </a>
               <a href="#" class="d-flex align-items-center border-bottom py-3">
                  <div class="mr-3">
                     <img src="{{ url('https://via.placeholder.com/35x35') }}" class="rounded-circle wd-35" alt="user">
                  </div>
                  <div class="w-100">
                     <div class="d-flex justify-content-between">
                        <h6 class="text-body mb-2">Jensen Combs</h6>
                        <p class="text-muted tx-12">08.22 PM</p>
                     </div>
                     <p class="text-muted tx-13">This template is awesome!</p>
                  </div>
               </a>
               <a href="#" class="d-flex align-items-center border-bottom py-3">
                  <div class="mr-3">
                     <img src="{{ url('https://via.placeholder.com/35x35') }}" class="rounded-circle wd-35" alt="user">
                  </div>
                  <div class="w-100">
                     <div class="d-flex justify-content-between">
                        <h6 class="text-body mb-2">Amiah Burton</h6>
                        <p class="text-muted tx-12">05.49 AM</p>
                     </div>
                     <p class="text-muted tx-13">Nice to meet you</p>
                  </div>
               </a>
               <a href="#" class="d-flex align-items-center border-bottom py-3">
                  <div class="mr-3">
                     <img src="{{ url('https://via.placeholder.com/35x35') }}" class="rounded-circle wd-35" alt="user">
                  </div>
                  <div class="w-100">
                     <div class="d-flex justify-content-between">
                        <h6 class="text-body mb-2">Yaretzi Mayo</h6>
                        <p class="text-muted tx-12">01.19 AM</p>
                     </div>
                     <p class="text-muted tx-13">Hey! there I'm available...</p>
                  </div>
               </a>
            </div>
         </div>
      </div>
   </div>
   <div class="col-lg-7 col-xl-8 stretch-card">
      <div class="card">
         <div class="card-body">
            <div class="d-flex justify-content-between align-items-baseline mb-2">
               <h6 class="card-title mb-0">Projects</h6>
               <div class="dropdown mb-2">
                  <button class="btn p-0" type="button" id="dropdownMenuButton7" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton7">
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="eye" class="icon-sm mr-2"></i> <span class="">View</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="edit-2" class="icon-sm mr-2"></i> <span class="">Edit</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="trash" class="icon-sm mr-2"></i> <span class="">Delete</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="printer" class="icon-sm mr-2"></i> <span class="">Print</span></a>
                     <a class="dropdown-item d-flex align-items-center" href="#"><i data-feather="download" class="icon-sm mr-2"></i> <span class="">Download</span></a>
                  </div>
               </div>
            </div>
            <div class="table-responsive">
               <table class="table table-hover mb-0">
                  <thead>
                     <tr>
                        <th class="pt-0">#</th>
                        <th class="pt-0">Project Name</th>
                        <th class="pt-0">Start Date</th>
                        <th class="pt-0">Due Date</th>
                        <th class="pt-0">Status</th>
                        <th class="pt-0">Assign</th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td>1</td>
                        <td>NobleUI jQuery</td>
                        <td>01/01/2020</td>
                        <td>26/04/2020</td>
                        <td><span class="badge badge-danger">Released</span></td>
                        <td>Leonardo Payne</td>
                     </tr>
                     <tr>
                        <td>2</td>
                        <td>NobleUI Angular</td>
                        <td>01/01/2020</td>
                        <td>26/04/2020</td>
                        <td><span class="badge badge-success">Review</span></td>
                        <td>Carl Henson</td>
                     </tr>
                     <tr>
                        <td>3</td>
                        <td>NobleUI ReactJs</td>
                        <td>01/05/2020</td>
                        <td>10/09/2020</td>
                        <td><span class="badge badge-info-muted">Pending</span></td>
                        <td>Jensen Combs</td>
                     </tr>
                     <tr>
                        <td>4</td>
                        <td>NobleUI VueJs</td>
                        <td>01/01/2020</td>
                        <td>31/11/2020</td>
                        <td><span class="badge badge-warning">Work in Progress</span>
                        </td>
                        <td>Amiah Burton</td>
                     </tr>
                     <tr>
                        <td>5</td>
                        <td>NobleUI Laravel</td>
                        <td>01/01/2020</td>
                        <td>31/12/2020</td>
                        <td><span class="badge badge-danger-muted text-white">Coming soon</span></td>
                        <td>Yaretzi Mayo</td>
                     </tr>
                     <tr>
                        <td>6</td>
                        <td>NobleUI NodeJs</td>
                        <td>01/01/2020</td>
                        <td>31/12/2020</td>
                        <td><span class="badge badge-primary">Coming soon</span></td>
                        <td>Carl Henson</td>
                     </tr>
                     <tr>
                        <td class="border-bottom">3</td>
                        <td class="border-bottom">NobleUI EmberJs</td>
                        <td class="border-bottom">01/05/2020</td>
                        <td class="border-bottom">10/11/2020</td>
                        <td class="border-bottom"><span class="badge badge-info-muted">Pending</span></td>
                        <td class="border-bottom">Jensen Combs</td>
                     </tr>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
--}} <!-- row -->
<script>
   var dataset1 = [
   @foreach ($sales as $i)
   
    
       {{$i->total_amount}},
   
     
   @endforeach
   ];
</script>
<script>
   var purchaseData = [
    {{ $p_jan}},{{$p_feb}},{{$p_mar}},{{$p_apr}},{{$p_may}},{{$p_jun}},{{$p_jul}},{{$p_aug}},{{$p_sep}},{{$p_oct}},{{$p_nov}},{{$p_dec}}
   ];
</script>
<script>
   var salesData = [
   {{ $s_jan}},{{$s_feb}},{{$s_mar}},{{$s_apr}},{{$s_may}},{{$s_jun}},{{$s_jul}},{{$s_aug}},{{$s_sep}},{{$s_oct}},{{$s_nov}},{{$s_dec}}
   ];
</script>
<script>
   var dataset2 = [
   @foreach ($purchase as $p)
   
    
       {{$p->total_amount}},
   
     
   @endforeach
   ];
</script>
<script>
   var dataset3 = [
   @foreach ($cash_bill as $ts)
   
    
       {{$ts->total_amount}},
   
     
   @endforeach
   ];
</script>
<script>
   var customerName = [
   @foreach ($customer_month as $cm)
   
    
       {{$cm->id}},
   
     
   @endforeach
   ];
</script>
<script>
   var supplierName = [
   @foreach ($supplier_month as $sm)
   
    
       {{$sm->id}},
   
     
   @endforeach
   ];
</script>
<script>
   var productName = [
   @foreach ($product_month as $pm)
   
    
       {{$pm->id}},
   
     
   @endforeach
   ];
</script>
@endsection
@push('plugin-scripts')
<script src="{{ asset('assets/plugins/chartjs/Chart.min.js') }}"></script>
<script src="{{ asset('assets/plugins/jquery.flot/jquery.flot.js') }}"></script>
<script src="{{ asset('assets/plugins/jquery.flot/jquery.flot.resize.js') }}"></script>
<script src="{{ asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js') }}"></script>
<script src="{{ asset('assets/plugins/apexcharts/apexcharts.min.js') }}"></script>
<script src="{{ asset('assets/plugins/progressbar-js/progressbar.min.js') }}"></script>
<script src="{{ asset('assets/plugins/peity/jquery.peity.min.js') }}"></script>
<script src="{{ asset('assets/plugins/chartjs/Chart.min.js') }}"></script>
<script src="{{ asset('assets/plugins/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
@endpush
@push('custom-scripts')
<script src="{{ asset('assets/js/dashboard.js') }}"></script>
<script src="{{ asset('assets/js/datepicker.js') }}"></script>
<script src="{{ asset('assets/js/peity.js') }}"></script>
<script src="{{ asset('assets/js/chartjs.js') }}"></script>
<script src="{{ asset('assets/js/sparkline.js') }}"></script>
@endpush