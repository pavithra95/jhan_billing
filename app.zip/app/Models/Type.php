<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'subcategory_id',
        'status',
    ];
    function sub()
    {
        return $this->belongsTo(SubCategory::class, 'subcategory_id');
    }
}